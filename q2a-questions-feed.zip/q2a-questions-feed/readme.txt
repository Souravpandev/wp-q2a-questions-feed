=== Q2A Questions Feed ===
Plugin Name: Q2A Questions Feed
Plugin URI: https://github.com/Souravpandev/wp-q2a-questions-feed
Description: Display Question2Answer questions from an RSS feed using shortcode or widget
Version: 1.0.0
Author: Sourav Pan
Author URI: https://wpoptimizelab.com/
Text Domain: q2a-feed
Domain Path: /languages
Requires at least: 5.0
Requires PHP: 7.2

Display questions from a Question2Answer RSS feed on your WordPress site using a shortcode or widget.

== Description ==

Q2A Questions Feed is a lightweight WordPress plugin that allows you to display questions from a Question2Answer RSS feed on your WordPress site. You can display the questions using a shortcode or a widget, with customizable display options.

### Features

* Display Q2A questions using a simple shortcode
* Add questions to any widget area
* Customize the number of questions to display
* Show/hide question dates
* Show/hide question excerpts
* Control excerpt length
* Caching for better performance
* Responsive design that works on all devices
* Easy to customize with CSS

== Installation ==

1. Upload the `q2a-questions-feed` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings > Q2A Feed to configure the plugin
4. Use the shortcode `[q2a_questions]` in your posts/pages or add the Q2A Questions Feed widget to your sidebar

== Frequently Asked Questions ==

= How do I find my Q2A RSS feed URL? =

Your Q2A RSS feed is typically available at `https://your-q2a-site.com/feed/qa.rss`

= Can I customize the appearance? =

Yes, you can customize the appearance by adding CSS to your theme's stylesheet. The plugin includes semantic HTML with appropriate classes for easy styling.

= How often is the feed updated? =

The feed is cached for a configurable amount of time (default: 1 hour) to improve performance. You can change this in the plugin settings.

== Screenshots ==

1. Q2A Feed Settings Page
2. Q2A Questions Widget
3. Example of questions displayed with shortcode

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release.
