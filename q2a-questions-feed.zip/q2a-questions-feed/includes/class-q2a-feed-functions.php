<?php
/**
 * Helper functions for Q2A Feed plugin
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Clear all transients used by the plugin
 */
function q2a_feed_clear_transients() {
    global $wpdb;
    
    // Delete all transients with our prefix
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM $wpdb->options WHERE option_name LIKE %s OR option_name LIKE %s",
            '_transient_q2a_feed_%',
            '_transient_timeout_q2a_feed_%'
        )
    );
    
    return true;
}

/**
 * Register and enqueue frontend styles and scripts
 */
function q2a_feed_enqueue_styles() {
    // Only load on frontend
    if (is_admin()) {
        return;
    }
    
    // Register the style
    wp_register_style(
        'q2a-feed-styles',
        plugins_url('assets/css/q2a-feed.min.css', dirname(__FILE__)),
        array(),
        '1.0.0'
    );
    
    // The style will be enqueued when the shortcode or widget is displayed
}
add_action('wp_enqueue_scripts', 'q2a_feed_enqueue_styles');

/**
 * Shortcode handler
 * 
 * @param array $atts Shortcode attributes
 * @return string HTML output
 */
function q2a_feed_shortcode($atts) {
    // Enqueue the style when shortcode is used
    wp_enqueue_style('q2a-feed-styles');
    
    $q2a_feed = Q2A_Feed::get_instance();
    return $q2a_feed->render_shortcode($atts);
}
add_shortcode('q2a_questions', 'q2a_feed_shortcode');

/**
 * Get the default options
 * 
 * @return array Default options
 */
function q2a_feed_get_default_options() {
    return array(
        'feed_url' => 'https://lightgreen-nightingale-283490.hostingersite.com/feed/qa.rss',
        'max_items' => 5,
        'cache_time' => 3600,
        'show_date' => true,
        'show_excerpt' => true,
        'excerpt_length' => 100,
    );
}

/**
 * Get a specific option or all options
 * 
 * @param string $key Optional. The option key to get
 * @param mixed $default Optional. Default value if option doesn't exist
 * @return mixed The option value or array of all options
 */
function q2a_feed_get_option($key = '', $default = null) {
    $options = get_option('q2a_feed_options', q2a_feed_get_default_options());
    
    if (empty($key)) {
        return $options;
    }
    
    return isset($options[$key]) ? $options[$key] : $default;
}
