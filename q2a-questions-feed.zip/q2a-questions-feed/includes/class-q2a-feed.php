<?php
/**
 * Main plugin class
 */
class Q2A_Feed {
    private static $instance = null;
    private $transient_time = 3600; // 1 hour cache
    private $default_feed_url = 'https://www.question2answer.org/qa/feed/qa.rss';
    
    /**
     * Get the singleton instance
     *
     * @return Q2A_Feed
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Register shortcode
        add_shortcode('q2a_questions', array($this, 'render_shortcode'));
        
        // Initialize widget
        add_action('widgets_init', array($this, 'register_widget'));
    }

    /**
     * Plugin activation
     */
    public static function activate() {
        // Add default options on activation
        if (false === get_option('q2a_feed_options')) {
            $defaults = array(
                'title' => __('Recent Questions', 'q2a-feed'),
                'count' => 5,
                'show_category' => true,
                'show_date' => true,
                'show_excerpt' => true,
                'excerpt_length' => 100,
            );
            update_option('q2a_feed_options', array_merge($defaults, array(
                'feed_url' => 'https://www.question2answer.org/qa/feed/qa.rss',
                'cache_time' => 3600,
            )));
        }
        
        // Schedule any required events
        if (!wp_next_scheduled('q2a_feed_clear_cache_event')) {
            wp_schedule_event(time(), 'twicedaily', 'q2a_feed_clear_cache_event');
        }
    }
    
    /**
     * Plugin deactivation
     */
    public static function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('q2a_feed_clear_cache_event');
        
        // Clean up transients
        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $wpdb->options WHERE option_name LIKE %s OR option_name LIKE %s",
                '_transient_q2a_feed_%',
                '_transient_timeout_q2a_feed_%'
            )
        );
    }

    /**
     * Fetch and parse the RSS feed
     */
    public function get_feed_items($count = 5) {
        $options = get_option('q2a_feed_options');
        $transient_key = 'q2a_feed_items_' . md5($options['feed_url']);
        
        // Try to get cached data first
        $cached = get_transient($transient_key);
        if (false !== $cached) {
            return $cached;
        }

        // If no cache, fetch the feed
        $feed_url = !empty($options['feed_url']) ? $options['feed_url'] : $this->default_feed_url;
        $response = wp_remote_get($feed_url, array('timeout' => 15));

        if (is_wp_error($response)) {
            return array();
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            return array();
        }

        // Parse the XML
        $xml = simplexml_load_string($body);
        if (false === $xml) {
            return array();
        }

        $items = array();
        $count = min($count, 20); // Limit to 20 items max for performance
        $i = 0;

        foreach ($xml->channel->item as $item) {
            if ($i >= $count) break;
            
            // Extract category from the feed item
            $category = '';
            
            // Get category (first category if multiple exist)
            if (isset($item->category)) {
                $category = (string)$item->category;
                if (is_array($item->category)) {
                    $category = (string)$item->category[0];
                }
                // Clean up the category text if needed
                $category = trim($category);
            }
            
            $items[] = array(
                'title' => (string)$item->title,
                'link' => (string)$item->link,
                'date' => strtotime((string)$item->pubDate),
                'description' => (string)$item->description,
                'category' => $category,
            );
            $i++;
        }

        // Cache the results
        set_transient($transient_key, $items, $options['cache_time']);
        
        return $items;
    }

    /**
     * Render the shortcode
     */
    public function render_shortcode($atts) {
        $options = get_option('q2a_feed_options');
        
        $atts = shortcode_atts(array(
            'count' => !empty($options['max_items']) ? $options['max_items'] : 5,
            'show_author' => !empty($options['show_author']) ? $options['show_author'] : true,
            'show_category' => !empty($options['show_category']) ? $options['show_category'] : true,
            'show_date' => !empty($options['show_date']) ? $options['show_date'] : true,
            'show_excerpt' => !empty($options['show_excerpt']) ? $options['show_excerpt'] : true,
            'excerpt_length' => !empty($options['excerpt_length']) ? $options['excerpt_length'] : 100,
        ), $atts, 'q2a_questions');

        $items = $this->get_feed_items($atts['count']);
        
        if (empty($items)) {
            return '<p>No questions found.</p>';
        }

        ob_start();
        ?>
        <div class="q2a-questions-feed">
            <ul class="q2a-questions-list">
                <?php foreach ($items as $item): ?>
                    <li class="q2a-question-item">
                        <h4 class="q2a-question-title">
                            <a href="<?php echo esc_url($item['link']); ?>" target="_blank">
                                <?php echo esc_html($item['title']); ?>
                            </a>
                        </h4>
                        <?php if ($atts['show_category'] && !empty($item['category'])): ?>
                            <div class="q2a-question-meta q2a-question-category">
                                <?php echo esc_html($item['category']); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($atts['show_date']): ?>
                            <div class="q2a-question-date">
                                <?php echo date_i18n(get_option('date_format'), $item['date']); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($atts['show_excerpt'] && !empty($item['description'])): ?>
                            <div class="q2a-question-excerpt">
                                <?php 
                                $excerpt = wp_trim_words(
                                    strip_shortcodes(strip_tags($item['description'])),
                                    $atts['excerpt_length'],
                                    '...'
                                );
                                echo esc_html($excerpt);
                                ?>
                            </div>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php
        
        // Enqueue styles
        wp_enqueue_style('q2a-feed-styles');
        
        return ob_get_clean();
    }

    /**
     * Register widget
     */
    public function register_widget() {
        register_widget('Q2A_Feed_Widget');
    }
}
