<?php
/**
 * Q2A Feed Widget
 */
class Q2A_Feed_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'q2a_feed_widget',
            __('Q2A Questions Feed', 'q2a-feed'),
            array(
                'description' => __('Display recent questions from Q2A', 'q2a-feed'),
                'classname' => 'q2a-feed-widget',
            )
        );
    }
    
    /**
     * Register the widget
     */
    public static function register() {
        register_widget( __CLASS__ );
    }

    /**
     * Front-end display of widget
     */
    public function widget($args, $instance) {
        $title = !empty($instance['title']) ? apply_filters('widget_title', $instance['title']) : '';
        $count = !empty($instance['count']) ? absint($instance['count']) : 5;
        $show_category = isset($instance['show_category']) ? (bool) $instance['show_category'] : true;
        $show_date = isset($instance['show_date']) ? (bool) $instance['show_date'] : true;
        $show_excerpt = isset($instance['show_excerpt']) ? (bool) $instance['show_excerpt'] : true;
        $excerpt_length = !empty($instance['excerpt_length']) ? absint($instance['excerpt_length']) : 100;

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . $title . $args['after_title'];
        }

        // Get the feed items
        $q2a_feed = Q2A_Feed::get_instance();
        $items = $q2a_feed->get_feed_items($count);

        if (empty($items)) {
            echo '<p>' . __('No questions found.', 'q2a-feed') . '</p>';
            echo $args['after_widget'];
            return;
        }
        ?>
        <ul class="q2a-widget-list">
            <?php foreach ($items as $item): ?>
                <li class="q2a-widget-item">
                    <h4 class="q2a-widget-title">
                        <a href="<?php echo esc_url($item['link']); ?>" target="_blank" rel="noopener">
                            <?php echo esc_html($item['title']); ?>
                        </a>
                    </h4>
                    
                    <?php if (($show_category && !empty($item['category'])) || $show_date): ?>
                        <div class="q2a-widget-meta">
                            <?php if ($show_category && !empty($item['category'])): ?>
                                <span class="q2a-widget-category">
                                    <?php echo esc_html($item['category']); ?>
                                </span>
                            <?php endif; ?>
                            <?php if ($show_date): ?>
                                <span class="q2a-widget-date">
                                    <?php echo date_i18n(get_option('date_format'), $item['date']); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($show_excerpt && !empty($item['description'])): ?>
                        <div class="q2a-widget-excerpt">
                            <?php 
                            $excerpt = wp_trim_words(
                                strip_shortcodes(wp_strip_all_tags($item['description'])), 
                                $excerpt_length, 
                                '...'
                            );
                            echo esc_html($excerpt);
                            ?>
                        </div>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php
        
        // Enqueue styles
        wp_enqueue_style('q2a-feed-styles');
        
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form
     */
    public function form($instance) {
        $defaults = array(
            'title' => __('Recent Questions', 'q2a-feed'),
            'count' => 5,
            'show_category' => true,
            'show_date' => true,
            'show_excerpt' => true,
            'excerpt_length' => 100,
        );
        
        $instance = wp_parse_args((array) $instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <?php _e('Title:', 'q2a-feed'); ?>
            </label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('count'); ?>">
                <?php _e('Number of questions to show:', 'q2a-feed'); ?>
            </label>
            <input id="<?php echo $this->get_field_id('count'); ?>" 
                   name="<?php echo $this->get_field_name('count'); ?>" 
                   type="number" min="1" max="20" step="1" 
                   value="<?php echo (int) $instance['count']; ?>" class="tiny-text" />
        </p>
        <p>
            <input class="checkbox" type="checkbox" 
                   id="<?php echo $this->get_field_id('show_category'); ?>" 
                   name="<?php echo $this->get_field_name('show_category'); ?>" 
                   <?php checked($instance['show_category']); ?> />
            <label for="<?php echo $this->get_field_id('show_category'); ?>">
                <?php _e('Display category?', 'q2a-feed'); ?>
            </label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" 
                   id="<?php echo $this->get_field_id('show_date'); ?>" 
                   name="<?php echo $this->get_field_name('show_date'); ?>" 
                   <?php checked($instance['show_date']); ?> />
            <label for="<?php echo $this->get_field_id('show_date'); ?>">
                <?php _e('Display post date?', 'q2a-feed'); ?>
            </label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" 
                   id="<?php echo $this->get_field_id('show_excerpt'); ?>" 
                   name="<?php echo $this->get_field_name('show_excerpt'); ?>" 
                   <?php checked($instance['show_excerpt']); ?> />
            <label for="<?php echo $this->get_field_id('show_excerpt'); ?>">
                <?php _e('Display excerpt?', 'q2a-feed'); ?>
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('excerpt_length'); ?>">
                <?php _e('Excerpt length (in words):', 'q2a-feed'); ?>
            </label>
            <input id="<?php echo $this->get_field_id('excerpt_length'); ?>" 
                   name="<?php echo $this->get_field_name('excerpt_length'); ?>" 
                   type="number" min="10" max="200" step="1" 
                   value="<?php echo (int) $instance['excerpt_length']; ?>" class="tiny-text" />
        </p>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved
     */
    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['count'] = absint($new_instance['count']);
        $instance['show_category'] = isset($new_instance['show_category']) ? (bool) $new_instance['show_category'] : false;
        $instance['show_date'] = isset($new_instance['show_date']) ? (bool) $new_instance['show_date'] : false;
        $instance['show_excerpt'] = isset($new_instance['show_excerpt']) ? (bool) $new_instance['show_excerpt'] : false;
        $instance['excerpt_length'] = absint($new_instance['excerpt_length']);
        
        // Clear the transient when settings are updated
        if (function_exists('q2a_feed_clear_transients')) {
            q2a_feed_clear_transients();
        }
        
        return $instance;
    }
}
