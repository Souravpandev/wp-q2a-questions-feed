<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package   Q2A_Questions_Feed
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Delete plugin options
delete_option( 'q2a_feed_options' );

// Clear any cached data
global $wpdb;
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM $wpdb->options WHERE option_name LIKE %s OR option_name LIKE %s",
        '_transient_q2a_feed_%',
        '_transient_timeout_q2a_feed_%'
    )
);

// Clear any scheduled hooks
wp_clear_scheduled_hook( 'q2a_feed_clear_cache_event' );
