<?php
/**
 * Plugin admin functionality
 */
class Q2A_Feed_Admin {
    private static $instance = null;
    private $options_page_hook = '';

    /**
     * Get the singleton instance
     *
     * @return Q2A_Feed_Admin
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_plugin_page'));
        add_action('admin_init', array($this, 'page_init'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_styles'));
        
        // Add settings link to plugins page
        add_filter('plugin_action_links_' . plugin_basename(dirname(dirname(__FILE__)) . '/q2a-questions-feed.php'), 
            array($this, 'add_settings_link'));
    }

    /**
     * Add options page
     */
    public function add_plugin_page() {
        $this->options_page_hook = add_options_page(
            'Q2A Feed Settings',
            'Q2A Feed',
            'manage_options',
            'q2a-feed-settings',
            array($this, 'create_admin_page')
        );
    }

    /**
     * Options page callback
     */
    public function create_admin_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Add error/update messages
        settings_errors('q2a_feed_messages');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('q2a_feed_options');
                do_settings_sections('q2a-feed-settings');
                submit_button('Save Settings');
                ?>
            </form>
            
            <div class="q2a-feed-documentation">
                <h2>Shortcode Usage</h2>
                <p>Use the following shortcode to display Q2A questions in your posts or pages:</p>
                <code>[q2a_questions count="5" show_date="1" show_excerpt="1" excerpt_length="100"]</code>
                
                <h3>Parameters:</h3>
                <ul>
                    <li><strong>count</strong> (int) - Number of questions to display (default: 5, max: 20)</li>
                    <li><strong>show_date</strong> (0/1) - Whether to show the post date (default: 1)</li>
                    <li><strong>show_excerpt</strong> (0/1) - Whether to show the excerpt (default: 1)</li>
                    <li><strong>excerpt_length</strong> (int) - Number of words in the excerpt (default: 100)</li>
                </ul>
                
                <h2>Widget</h2>
                <p>You can also add the Q2A Questions Feed widget from Appearance > Widgets.</p>
                
                <h2>Cache</h2>
                <p>The feed is cached for better performance. The cache is automatically cleared when you save settings.</p>
                <p>
                    <a href="<?php echo wp_nonce_url(admin_url('options-general.php?page=q2a-feed-settings&action=clear_cache'), 'q2a_clear_cache'); ?>" 
                       class="button button-secondary">
                        <?php _e('Clear Cache Now', 'q2a-feed'); ?>
                    </a>
                </p>
            </div>
        </div>
        <?php
    }

    /**
     * Register and add settings
     */
    public function page_init() {
        register_setting(
            'q2a_feed_options',
            'q2a_feed_options',
            array($this, 'sanitize')
        );

        // General Settings Section
        add_settings_section(
            'q2a_feed_general_section',
            'General Settings',
            array($this, 'print_section_info'),
            'q2a-feed-settings'
        );

        // Feed URL
        add_settings_field(
            'feed_url',
            'Q2A RSS Feed URL',
            array($this, 'feed_url_callback'),
            'q2a-feed-settings',
            'q2a_feed_general_section'
        );

        // Max Items
        add_settings_field(
            'max_items',
            'Maximum Items to Show',
            array($this, 'max_items_callback'),
            'q2a-feed-settings',
            'q2a_feed_general_section'
        );

        // Cache Time
        add_settings_field(
            'cache_time',
            'Cache Duration (seconds)',
            array($this, 'cache_time_callback'),
            'q2a-feed-settings',
            'q2a_feed_general_section'
        );

        // Display Options Section
        add_settings_section(
            'q2a_feed_display_section',
            'Display Options',
            array($this, 'print_display_section_info'),
            'q2a-feed-settings'
        );

        // Show Category
        add_settings_field(
            'show_category',
            'Show Category',
            array($this, 'show_category_callback'),
            'q2a-feed-settings',
            'q2a_feed_display_section'
        );
        
        // Show Date
        add_settings_field(
            'show_date',
            'Show Date',
            array($this, 'show_date_callback'),
            'q2a-feed-settings',
            'q2a_feed_display_section'
        );

        // Show Excerpt
        add_settings_field(
            'show_excerpt',
            'Show Excerpt',
            array($this, 'show_excerpt_callback'),
            'q2a-feed-settings',
            'q2a_feed_display_section'
        );

        // Excerpt Length
        add_settings_field(
            'excerpt_length',
            'Excerpt Length (words)',
            array($this, 'excerpt_length_callback'),
            'q2a-feed-settings',
            'q2a_feed_display_section'
        );
        
        // Handle cache clearing
        if (isset($_GET['action']) && $_GET['action'] === 'clear_cache' && 
            check_admin_referer('q2a_clear_cache')) {
            $this->clear_cache();
            add_settings_error(
                'q2a_feed_messages',
                'q2a_cache_cleared',
                'Cache has been cleared.',
                'updated'
            );
        }
    }

    /**
     * Sanitize each setting field as needed
     */
    public function sanitize($input) {
        $new_input = array();
        
        if (isset($input['feed_url'])) {
            $new_input['feed_url'] = esc_url_raw($input['feed_url']);
        }
        
        $new_input['show_category'] = isset($input['show_category']) ? 1 : 0;
        
        if (isset($input['max_items'])) {
            $new_input['max_items'] = absint($input['max_items']);
            if ($new_input['max_items'] > 20) $new_input['max_items'] = 20;
            if ($new_input['max_items'] < 1) $new_input['max_items'] = 1;
        }
        
        if (isset($input['cache_time'])) {
            $new_input['cache_time'] = absint($input['cache_time']);
            if ($new_input['cache_time'] < 300) $new_input['cache_time'] = 300; // Minimum 5 minutes
        }
        
        $new_input['show_date'] = isset($input['show_date']) ? 1 : 0;
        $new_input['show_excerpt'] = isset($input['show_excerpt']) ? 1 : 0;
        
        if (isset($input['excerpt_length'])) {
            $new_input['excerpt_length'] = absint($input['excerpt_length']);
            if ($new_input['excerpt_length'] < 10) $new_input['excerpt_length'] = 10;
            if ($new_input['excerpt_length'] > 500) $new_input['excerpt_length'] = 500;
        }
        
        // Clear the cache when settings are saved
        $this->clear_cache();
        
        // Add success message
        add_settings_error(
            'q2a_feed_messages',
            'settings_updated',
            'Settings Saved. Cache has been cleared.',
            'updated'
        );
        
        return $new_input;
    }

    /**
     * Clear all transients used by this plugin
     */
    private function clear_cache() {
        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $wpdb->options WHERE option_name LIKE %s OR option_name LIKE %s",
                '_transient_q2a_feed_%',
                '_transient_timeout_q2a_feed_%'
            )
        );
    }

    /**
     * Print the Section text
     */
    public function print_section_info() {
        print 'Enter your Q2A feed settings below:';
    }

    public function print_display_section_info() {
        print 'Customize how the questions are displayed. You can show/hide the author, category, date, and excerpt for each question.';
    }

    /**
     * Get the settings option array and print one of its values
     */
    public function feed_url_callback() {
        $options = get_option('q2a_feed_options');
        printf(
            '<input type="url" id="feed_url" name="q2a_feed_options[feed_url]" value="%s" class="regular-text" placeholder="https://example.com/feed/qa.rss" />',
            isset($options['feed_url']) ? esc_attr($options['feed_url']) : ''
        );
        echo '<p class="description">Enter the full URL to your Q2A RSS feed.</p>';
    }

    public function max_items_callback() {
        $options = get_option('q2a_feed_options');
        printf(
            '<input type="number" id="max_items" name="q2a_feed_options[max_items]" value="%s" min="1" max="20" step="1" class="small-text" />',
            isset($options['max_items']) ? esc_attr($options['max_items']) : '5'
        );
        echo '<p class="description">Maximum number of questions to display (1-20).</p>';
    }

    public function cache_time_callback() {
        $options = get_option('q2a_feed_options');
        printf(
            '<input type="number" id="cache_time" name="q2a_feed_options[cache_time]" value="%s" min="300" step="300" class="small-text" />',
            isset($options['cache_time']) ? esc_attr($options['cache_time']) : '3600'
        );
        echo '<p class="description">How long to cache the feed (in seconds). Minimum 300 (5 minutes).</p>';
    }

    public function show_category_callback() {
        $options = get_option('q2a_feed_options');
        printf(
            '<input type="checkbox" id="show_category" name="q2a_feed_options[show_category]" value="1" %s />',
            (isset($options['show_category']) && $options['show_category']) ? 'checked="checked"' : ''
        );
        echo '<label for="show_category">Show the category for each question</label>';
    }
    
    public function show_date_callback() {
        $options = get_option('q2a_feed_options');
        printf(
            '<input type="checkbox" id="show_date" name="q2a_feed_options[show_date]" value="1" %s />',
            (isset($options['show_date']) && $options['show_date']) ? 'checked="checked"' : ''
        );
        echo '<label for="show_date">Show the date for each question</label>';
    }

    public function show_excerpt_callback() {
        $options = get_option('q2a_feed_options');
        printf(
            '<input type="checkbox" id="show_excerpt" name="q2a_feed_options[show_excerpt]" value="1" %s />',
            (isset($options['show_excerpt']) && $options['show_excerpt']) ? 'checked="checked"' : ''
        );
        echo '<label for="show_excerpt">Show an excerpt for each question</label>';
    }

    public function excerpt_length_callback() {
        $options = get_option('q2a_feed_options');
        printf(
            '<input type="number" id="excerpt_length" name="q2a_feed_options[excerpt_length]" value="%s" min="10" max="500" step="1" class="small-text" />',
            isset($options['excerpt_length']) ? esc_attr($options['excerpt_length']) : '100'
        );
        echo '<p class="description">Maximum number of words in the excerpt (10-500).</p>';
    }

    /**
     * Enqueue admin-specific styles
     */
    public function enqueue_admin_styles($hook) {
        if ($hook !== $this->options_page_hook) {
            return;
        }
        
        wp_enqueue_style(
            'q2a-feed-admin',
            plugins_url('css/admin.css', dirname(__FILE__)),
            array(),
            '1.0.0'
        );
    }
    
    /**
     * Add settings link to plugins page
     */
    public function add_settings_link($links) {
        $settings_link = '<a href="' . admin_url('options-general.php?page=q2a-feed-settings') . '">' . __('Settings') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}
