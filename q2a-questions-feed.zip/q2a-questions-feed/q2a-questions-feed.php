<?php

/**
 * Plugin Name: Q2A Questions Feed
 * Plugin URI: https://github.com/Souravpandev/wp-q2a-questions-feed
 * Description: Display Question2Answer questions from an RSS feed using shortcode or widget
 * Version: 1.0.0
 * Author: Sourav Pan
 * Author URI: https://wpoptimizelab.com/
 * Text Domain: q2a-feed
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.2
 * 
 * @package Q2A_Questions_Feed
 */

// If this file is called directly, abort.
if (! defined('WPINC')) {
    die;
}

// Define plugin constants
define('Q2A_FEED_VERSION', '1.0.0');
define('Q2A_FEED_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('Q2A_FEED_PLUGIN_URL', plugin_dir_url(__FILE__));
define('Q2A_FEED_BASENAME', plugin_basename(__FILE__));

// Include required files
$includes = array(
    'includes/class-q2a-feed-functions.php',
    'includes/class-q2a-feed.php',
    'includes/class-q2a-feed-widget.php',
    'admin/class-q2a-feed-admin.php',
);

foreach ($includes as $file) {
    $file_path = Q2A_FEED_PLUGIN_DIR . $file;
    if (file_exists($file_path)) {
        require_once $file_path;
    } else {
        // Log error if file is missing
        error_log('Q2A Feed: Missing required file: ' . $file_path);
    }
}

// Check if all required files were loaded
if (! class_exists('Q2A_Feed') || ! class_exists('Q2A_Feed_Widget') || ! class_exists('Q2A_Feed_Admin')) {
    add_action('admin_notices', 'q2a_feed_missing_files_notice');
    return;
}

// Display admin notice for missing files
function q2a_feed_missing_files_notice()
{
?>
    <div class="notice notice-error">
        <p><?php _e('Q2A Feed: Some required plugin files are missing. Please reinstall the plugin.', 'q2a-feed'); ?></p>
    </div>
<?php
}

// Initialize the plugin
function q2a_feed_init()
{
    // Check if all required classes exist
    if (! class_exists('Q2A_Feed') || ! class_exists('Q2A_Feed_Widget') || ! class_exists('Q2A_Feed_Admin')) {
        return;
    }

    // Initialize main plugin class
    $q2a_feed = Q2A_Feed::get_instance();

    // Initialize admin
    if (is_admin()) {
        $q2a_feed_admin = Q2A_Feed_Admin::get_instance();
    }

    // Register widget
    add_action('widgets_init', array('Q2A_Feed_Widget', 'register'));
}
add_action('plugins_loaded', 'q2a_feed_init');

// Activation hook
register_activation_hook(__FILE__, array('Q2A_Feed', 'activate'));

// Deactivation hook
register_deactivation_hook(__FILE__, array('Q2A_Feed', 'deactivate'));

// Uninstall hook
register_uninstall_hook(__FILE__, 'q2a_feed_uninstall');

/**
 * Clean up on uninstall
 */
function q2a_feed_uninstall()
{
    // Delete options
    delete_option('q2a_feed_options');

    // Clear any cached data
    global $wpdb;
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM $wpdb->options WHERE option_name LIKE %s OR option_name LIKE %s",
            '_transient_q2a_feed_%',
            '_transient_timeout_q2a_feed_%'
        )
    );
}

// Load text domain for translations
function q2a_feed_load_textdomain()
{
    load_plugin_textdomain('q2a-feed', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'q2a_feed_load_textdomain');
